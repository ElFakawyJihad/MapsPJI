package com.example.pji.mapspji.api.dom.src.Exception;

public final class UserIsUsedException extends Exception{
	public UserIsUsedException(){
		System.out.println("User Name is Used");
	}
}
