package com.example.pji.mapspji.database.exception;

public class UserHaveNotGroupException extends Exception {
	public UserHaveNotGroupException(){
		System.out.println("Utilisateur n'as pas de groupe");
	}
}
