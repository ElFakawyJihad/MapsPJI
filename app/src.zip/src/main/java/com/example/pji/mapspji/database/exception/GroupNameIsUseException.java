package com.example.pji.mapspji.database.exception;

public class GroupNameIsUseException extends Exception{
	public GroupNameIsUseException(){
		System.out.println("Nom de groupe deja utilise");
	}
}
