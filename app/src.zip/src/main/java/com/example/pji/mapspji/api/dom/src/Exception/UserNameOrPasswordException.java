package com.example.pji.mapspji.api.dom.src.Exception;

public class UserNameOrPasswordException extends Exception {
	public UserNameOrPasswordException(){
		System.out.println("Password or User Name is False");
	}
}
