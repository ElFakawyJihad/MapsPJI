package com.example.pji.mapspji.database.exception;

public class UserOrPasswordFalseException extends Exception {
	public UserOrPasswordFalseException(){
		System.out.println("User or Password is false");
	}
}
